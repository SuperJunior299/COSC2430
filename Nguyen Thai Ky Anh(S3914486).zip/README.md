# COSC2430
MyCV_onl
Name:Nguyen Thai Ky Anh
Student_Id: S3914486
Link: https://superjunior299.github.io/COSC2430/

This is a website about me built entirely in html. In the website there will be 5 sections: homepage, projects, blog, about me, contact. The home page is where basic information about me is located. The project page is the projects I've been involved in. Blog page is my sharing about programming. The About page will be my information in detail. The Contact page is the place to fill in your contact information
